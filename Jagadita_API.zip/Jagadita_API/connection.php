<?php
    $host	= "hosting_database";
    $user	= "user_database";
    $pass	= "password_database";
    $db 	= "nama_database";
    

	$conn = new mysqli($host, $user, $pass, $db);

	if ($conn->connect_errno) {
		die('Koneksi Error: '.$mysqli->connect_errno. ' - '. $mysqli->connect_error);
	}